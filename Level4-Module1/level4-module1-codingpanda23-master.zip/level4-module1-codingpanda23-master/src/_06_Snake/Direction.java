package _06_Snake;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
