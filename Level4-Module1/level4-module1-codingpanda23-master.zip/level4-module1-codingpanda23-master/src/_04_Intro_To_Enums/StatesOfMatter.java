package _04_Intro_To_Enums;

public enum StatesOfMatter {
	SOLID, LIQUID, GAS, PLASMA, BOSE_EINSTEIN_CONDENSATE
}
